@echo off
chcp 65001 > nul
title Telegram Professional Yordamchi Bot
echo =========================================================
echo       Telegram Shaxsiy Yordamchi Bot ishga tushmoqda...
echo =========================================================
py bot.py
pause
